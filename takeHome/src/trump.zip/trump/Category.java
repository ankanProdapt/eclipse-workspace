package trump;

public interface Category {
	
	int compare(Integer score1, Integer score2);
}
